
To run this demonstration
-------------------------

To run the trigger demonstration, enter the following;

Windows: java -cp ../../mckoidb.jar;. TriggerDemo
Unix:    java -cp ../../mckoidb.jar:. TriggerDemo

This demo will create a database and perform queries that fire
triggers that have been set.  If you wish to run the demo
again, remember to delete the 'log' and 'data' sub-directories.

